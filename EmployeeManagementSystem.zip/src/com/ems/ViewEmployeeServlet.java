package com.ems;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ViewEmployeeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Employees</title><link rel='stylesheet' href='css/style.css'></head><body><div class='container'>");
        out.println("<h2>Employee List</h2>");

        try (Connection con = DBConnection.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employees");

            out.println("<table border='1'><tr><th>ID</th><th>Name</th><th>Email</th><th>Department</th><th>Salary</th></tr>");
            while (rs.next()) {
                out.println("<tr><td>" + rs.getInt("id") + "</td><td>" +
                    rs.getString("name") + "</td><td>" +
                    rs.getString("email") + "</td><td>" +
                    rs.getString("department") + "</td><td>" +
                    rs.getDouble("salary") + "</td></tr>");
            }
            out.println("</table>");
        } catch (Exception e) {
            e.printStackTrace();
        }
        out.println("</div></body></html>");
    }
}